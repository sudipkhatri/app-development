//
//  Triangle.swift
//  AssignS4613222
//
//  Created by students on 11/2/20.
//  Copyright © 2020 RR. All rights reserved.
//

import UIKit

class Triangle: UIViewController {

    @IBOutlet weak var sidea: UITextField!
    @IBOutlet weak var sideb: UITextField!
    @IBOutlet weak var sidec: UITextField!
    @IBOutlet weak var Results: UITextField!
    
    
    @IBAction func triClick(_ sender: Any) {
        let a = Float(sidea.text!)
        let b = Float(sideb.text!)
        let c = Float(sidec.text!)
        if a==b && b == c {
            Results.text = String("Triangle is Equilaterial");
        }
        else if a==b && a==c {
            Results.text = String("Triangle is Isoceles");
        }
        else{
            Results.text = String("Triangle is Scalene");
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
