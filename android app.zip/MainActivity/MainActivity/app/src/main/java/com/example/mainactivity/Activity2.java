package com.example.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {
    // defining Id for allocation
    private EditText et;
    private EditText et2;
    private EditText et3;
    private EditText et4;
    private Button b3;
    private TextView tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        // defining id to their respective variables/orders
        et = (EditText) findViewById(R.id.et);
        et2 = (EditText) findViewById(R.id.et2);
        et3 = (EditText) findViewById(R.id.et3);
        et4 = (EditText) findViewById(R.id.et4);
        tv2 = (TextView) findViewById(R.id.tv2);
        b3 = (Button) findViewById(R.id.b3);

        b3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // if user input equal to null
                if(et.getText().toString().length() ==0){
                    et.setText("0");
                }
                if(et2.getText().toString().length() ==0){
                    et2.setText("0");
                }
                if(et3.getText().toString().length() ==0){
                    et3.setText("0");
                }
                if(et4.getText().toString().length() ==0){
                    et4.setText("0");
                }
                // string value conversion
                double rate = Double.valueOf(et.getText().toString());
                double hours = Double.valueOf(et2.getText().toString());
                double ot = Double.valueOf(et3.getText().toString());
                double ot_rate = Double.valueOf(et4.getText().toString());
                double salary = (rate * hours) + (ot * ot_rate);
                //
                tv2.setText(String.valueOf(salary));
            }



        });

    }
}
