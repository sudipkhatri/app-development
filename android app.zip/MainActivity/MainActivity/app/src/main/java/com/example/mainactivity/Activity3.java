package com.example.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {

    private EditText eText;
    private EditText eText2;
    private EditText eText3;
    private Button button3;
    private TextView teV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        button3 = (Button) findViewById(R.id.button3);
        eText = (EditText) findViewById(R.id.eText);
        eText2 = (EditText) findViewById(R.id.eText2);
        eText3 = (EditText) findViewById(R.id.eText3);
        teV = (TextView) findViewById(R.id.teV);

        button3.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){

                int side1 = Integer.valueOf(eText.getText().toString());
                int side2 = Integer.valueOf(eText2.getText().toString());
                int side3 = Integer.valueOf(eText3.getText().toString());

                if((side1 == side2) && (side1 == side3) && (side2==side3) ) {
                    teV.setText("Equalateral Triangle");
                }
                else if(side1 == side2 || side1 == side3 || side2 == side3) {
                    teV.setText("Isoceles Triangle");
                }
                else {
                    teV.setText("Scalene Triangle");
                }

            }
        });
    }
}
